## Daring 0.1.5

* Add themeable border at top of body.
* Add themeable input buttons for forms.
* Improve readability with bigger larger font for tablets and desktops.
* Adjust widths.

## Daring 0.1.4

* Fix styling for tag page descriptions to make them stand out from the tag     name.

## Daring 0.1.3

* Fix bug in main navigation list items.

## Daring 0.1.2

* Add responsive styling.

## Daring 0.1.1

* Tidy up author template.
* Add license.
* Add changelog.
* Add Facebook link.
