$(document).ready(function() {

  'use strict';

  $('.wrapper').fitVids();
});