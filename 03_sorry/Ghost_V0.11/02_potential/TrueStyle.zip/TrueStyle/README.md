# from
https://github.com/Zazama/TrueStyle

# TrueStyle
TrueStyle is a responsive Bootstrap Theme for Ghost (working with Ghost 0.6.4).

It supports the latest updates and has the navigation helper implemented.

You can find a demo here: http://truestyle.zazama.de/

# How to use Disqus
To use Disqus, open the post.hbs and search for "var disqus_shortname". Now edit the "!!!!!!!!ENTER YOUR DISQUS SHORTNAME HERE!!!!!!" to your Disqus shortname. Don't delete the ' ' !
