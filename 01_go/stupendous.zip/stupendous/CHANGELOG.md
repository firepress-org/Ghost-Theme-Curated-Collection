# 2.0.0 - 2017-07-29
  - Support Ghost 1.0.0

# 1.5.3 - 2017-07-01
  - Fix cover image height

# 1.5.2 - 2017-07-01
  - Show cover image of post in next/prev post container

# 1.5.1 - 2017-06-21
  - Fix layout in page and post views
  - Fix sizing of prev/next article suggestion
  - Remove extra spacing on top of page and post layouts
  - Next/previous suggested post flex basis should depend on max-width

# 1.5.0 - 2017-06-17
  - Update how the navigation bar looks like
  - Make design a little more mobile friendly
  - Remove social icons, only use fontawesome for icons

# 1.4.0 - 2016-03-18
  - Add custom navigation support
  - Add additional icons (icons from [iconfinder/social-hand-drawn-icons](https://www.iconfinder.com/iconsets/social-hand-drawn-icons))
  - Fix static page style

# 1.3.1 - 2015-07-23
  - Fix read-next display on Safari [#1](https://github.com/dcefram/stupendous/issues/1)
  - Fix grunt's stylus task to point to correct folder path
  - Change versioning from m.m to m.m.p (major.minor.patch)
  - Change spacing from 4 spaces to 2 spaces for both JS and Stylus files

# 1.3.0 - 2015-04-23
  - Added prism for code syntax highlight
  - Updated previous post style

# 1.2.0 - 2015-04-20
  - Added support for previous and next post links
  - Added jeet to stylus folder (due to compilation failure on different environments)

# 1.1.0 - 2015-03-10
  - Added tag.hbs
  - Use asset helper for favicons
  - Add google-code-prettify for prettifying codes

# 1.0.0 - 2015-03-02
