# Crisply

https://github.com/pyrmont/crisply

Crisply is a theme for [Ghost](http://ghost.org), a content-management system. It is a modified version of [Crisp](http://github.com/kathyqian/crisp) by [Kathy Qian](http://kathyqian.com).

### License

This theme is licensed under the [MIT License](https://github.com/kathyqian/crisp/blob/master/license.txt).