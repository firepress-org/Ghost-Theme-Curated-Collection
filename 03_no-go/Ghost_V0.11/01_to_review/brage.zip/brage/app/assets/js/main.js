document.addEventListener("DOMContentLoaded", function () {
  hljs.initHighlightingOnLoad();
});
