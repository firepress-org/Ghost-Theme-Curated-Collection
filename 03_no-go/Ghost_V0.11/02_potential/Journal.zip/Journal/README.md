# from
https://github.com/yuanliang/yuanliang.io

Journal, minimal ghost theme.

Journal Ghost theme is licensed under the General Public
License (GPL). You will find a copy of the GPL in the same directory 
as this text file.

Developed in July 2015. by Stefan Djokic (djokics@elfak.rs)
