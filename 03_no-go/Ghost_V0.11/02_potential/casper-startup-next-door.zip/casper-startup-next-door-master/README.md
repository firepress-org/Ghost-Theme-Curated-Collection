# Casper - Startup Next Door

A fork of the default theme for [Ghost](http://github.com/tryghost/ghost/).

To download, visit the [releases](https://github.com/TryGhost/Casper/releases) page.

## Change these:

- Theme name in casper-startup-next-door/package.json line 2
- disqus_shortname in casper-startup-next-door/post.hbs line 82
- domain name in casper-startup-next-door/post.hbs line 84
- disqus_shortname in casper-startup-next-door/default.hbs line 53