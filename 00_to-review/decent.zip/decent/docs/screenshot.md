### Home page

![home page](../screenshot/homepage.jpg)

### Post page

![post page](../screenshot/post.jpg)

### Author page

![author page](../screenshot/author.jpg)

### Tag page

![tag page](../screenshot/tag.jpg)
